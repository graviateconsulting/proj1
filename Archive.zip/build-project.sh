#!/bin/bash

echo "Building the project..."

# Clean and build the project
sbt clean assembly

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "Build successful. Copying JAR file..."
    
    # Copy the JAR file to the expected location
    cp target/scala-2.12/tetra-elevate-conversion_2.12-1.0.jar jar/
    
    if [ $? -eq 0 ]; then
        echo "JAR file copied successfully to jar/ directory"
        echo "You can now run: ./scripts/dlm_serializedmaterialExtract.sh SUPPLY_CHAIN"
    else
        echo "Failed to copy JAR file"
        exit 1
    fi
else
    echo "Build failed. Please check the error messages above."
    exit 1
fi