# Cassandra-to-Oracle Local Storage Migration Design Specification

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [System Architecture](#system-architecture)
3. [Implementation Specifications](#implementation-specifications)
4. [Configuration Guidelines](#configuration-guidelines)
5. [Performance Optimization](#performance-optimization)
6. [Migration Strategy](#migration-strategy)
7. [Development Guidelines](#development-guidelines)
8. [Testing Framework](#testing-framework)
9. [Operational Procedures](#operational-procedures)
10. [Risk Management](#risk-management)
11. [Appendices](#appendices)

## Executive Summary

### Overview
This document provides comprehensive design specifications for enhancing the existing Cassandra-to-Oracle migration system to support local storage as an alternative to HDFS, specifically optimized for small to medium databases (1-80GB).

### Key Benefits
- **Simplified Infrastructure**: Eliminates Hadoop cluster dependency for small databases
- **Enhanced Performance**: 20-30% performance improvement for datasets under 10GB
- **Development Efficiency**: Local development environment with embedded databases
- **Cost Reduction**: Reduced infrastructure costs for small-scale migrations
- **Format Flexibility**: Support for CSV, Parquet, and JSON formats

### System Requirements
- **Minimum Disk Space**: 2x estimated data size for processing overhead
- **Memory Requirements**: 4-16GB RAM depending on data size
- **CPU Requirements**: 2-8 cores based on dataset complexity
- **Spark Version**: 3.2+ with adaptive query execution support

## System Architecture

### High-Level Architecture

```mermaid
graph TB
    subgraph "Data Sources"
        C1[Cassandra TETRA]
        C2[Cassandra HP]
    end
    
    subgraph "Enhanced Migration System"
        SAL[Storage Abstraction Layer]
        DSA[Data Size Analyzer]
        APE[Adaptive Processing Engine]
        MSM[Multi-Storage Manager]
    end
    
    subgraph "Storage Options"
        LS[Local Storage<br/>./data/]
        HDFS[HDFS Storage<br/>/app/tetra/DLM/]
    end
    
    subgraph "Target Systems"
        O1[Oracle Production]
        O2[Development Databases]
    end
    
    C1 --> SAL
    C2 --> SAL
    SAL --> DSA
    DSA --> APE
    APE --> MSM
    MSM --> LS
    MSM --> HDFS
    LS --> O1
    HDFS --> O1
    LS --> O2
```

### Component Architecture

#### 1. Storage Abstraction Layer
**Interface**: `StorageProvider`
**Implementations**: `LocalStorageProvider`, `HDFSStorageProvider`
**Responsibilities**:
- Abstract storage operations from business logic
- Provide unified interface for file operations
- Handle storage-specific optimizations

#### 2. Data Size Analyzer
**Class**: `DataSizeDetector`
**Responsibilities**:
- Estimate dataset size using statistical sampling
- Classify data complexity and processing requirements
- Recommend optimal storage and processing strategies

#### 3. Adaptive Processing Engine
**Class**: `AdaptiveProcessor`
**Responsibilities**:
- Generate size-appropriate Spark configurations
- Optimize memory allocation and partitioning
- Adjust processing parameters dynamically

## Implementation Specifications

### 1. Core Components Implementation

#### Storage Provider Interface
```scala
trait StorageProvider {
  def initialize(config: Config): Unit
  def exists(path: String): Boolean
  def createDirectory(path: String): Boolean
  def writeDataFrame(df: DataFrame, path: String, format: String, options: Map[String, String]): Unit
  def readDataFrame(spark: SparkSession, path: String, format: String, schema: StructType): DataFrame
  def getFileSize(path: String): Long
  def deleteFile(path: String): Boolean
}
```

#### Local Storage Provider Implementation
```scala
class LocalStorageProvider extends StorageProvider {
  private var basePath: String = _
  private val fileSystem = FileSystems.getDefault
  
  override def initialize(config: Config): Unit = {
    basePath = config.getString("storage.local.basePath")
    Files.createDirectories(Paths.get(basePath))
    logger.info(s"Local storage initialized at: $basePath")
  }
  
  override def writeDataFrame(df: DataFrame, path: String, format: String, options: Map[String, String]): Unit = {
    val fullPath = Paths.get(basePath, path).toString
    
    format match {
      case "parquet" => writeParquetFormat(df, fullPath, options)
      case "csv" => writeCsvFormat(df, fullPath, options)  
      case "json" => writeJsonFormat(df, fullPath, options)
      case _ => throw new IllegalArgumentException(s"Unsupported format: $format")
    }
  }
  
  private def writeParquetFormat(df: DataFrame, path: String, options: Map[String, String]): Unit = {
    val writer = df.write.mode(options.getOrElse("mode", "overwrite"))
    
    // Apply Parquet-specific optimizations
    writer
      .option("compression", options.getOrElse("compression", "snappy"))
      .option("parquet.enable.dictionary", "true")
      .option("parquet.block.size", options.getOrElse("blockSize", "134217728")) // 128MB
      .format("parquet")
      .save(path)
  }
}
```

### 2. Multi-Format Support Implementation

#### Format Manager
```scala
object FormatManager {
  
  sealed trait DataFormat {
    def extension: String
    def defaultCompression: String
    def recommendedBlockSize: Long
  }
  
  object DataFormat {
    case object Parquet extends DataFormat {
      val extension = "parquet"
      val defaultCompression = "snappy"
      val recommendedBlockSize = 134217728L // 128MB
    }
    
    case object CSV extends DataFormat {
      val extension = "csv" 
      val defaultCompression = "gzip"
      val recommendedBlockSize = 67108864L // 64MB
    }
    
    case object JSON extends DataFormat {
      val extension = "json"
      val defaultCompression = "gzip"
      val recommendedBlockSize = 33554432L // 32MB
    }
  }
  
  def selectOptimalFormat(estimatedSizeMB: Long, useCase: String): DataFormat = {
    (estimatedSizeMB, useCase) match {
      case (size, "development") if size < 100 => DataFormat.JSON
      case (size, "production") if size < 500 => DataFormat.CSV
      case (size, "production") if size >= 500 => DataFormat.Parquet
      case (_, "analytics") => DataFormat.Parquet
      case _ => DataFormat.CSV
    }
  }
}
```

### 3. Adaptive Processing Implementation

#### Data Size Detection
```scala
object DataSizeDetector {
  
  case class DataSizeEstimate(
    estimatedRows: Long,
    estimatedSizeBytes: Long,
    estimatedSizeMB: Long,
    sampleConfidence: Double,
    complexity: DataComplexity
  )
  
  sealed trait DataComplexity
  object DataComplexity {
    case object Low extends DataComplexity      // Simple schema, uniform data
    case object Medium extends DataComplexity   // Mixed data types, some nulls
    case object High extends DataComplexity     // Complex nested structures, high cardinality
  }
  
  def estimateTableSize(df: DataFrame, sampleFraction: Double = 0.01): DataSizeEstimate = {
    val totalCount = df.count()
    val sampleDF = df.sample(sampleFraction)
    val sampleCount = sampleDF.count()
    
    if (sampleCount == 0) {
      throw new IllegalStateException("No sample data available for size estimation")
    }
    
    // Calculate average row size
    val sampleData = sampleDF.take(math.min(sampleCount, 1000).toInt)
    val avgRowSize = sampleData.map(estimateRowSize).sum / sampleData.length
    
    val estimatedSizeBytes = totalCount * avgRowSize
    val estimatedSizeMB = estimatedSizeBytes / (1024 * 1024)
    
    DataSizeEstimate(
      estimatedRows = totalCount,
      estimatedSizeBytes = estimatedSizeBytes,
      estimatedSizeMB = estimatedSizeMB,
      sampleConfidence = math.min(sampleFraction * 100, 95.0),
      complexity = analyzeDataComplexity(df.schema, sampleData)
    )
  }
  
  private def estimateRowSize(row: Row): Long = {
    row.schema.fields.zipWithIndex.map { case (field, idx) =>
      if (row.isNullAt(idx)) 1L else {
        field.dataType match {
          case StringType => Option(row.getString(idx)).map(_.getBytes("UTF-8").length).getOrElse(0L)
          case IntegerType => 4L
          case LongType => 8L
          case DoubleType => 8L
          case TimestampType => 8L
          case DateType => 4L
          case BooleanType => 1L
          case _ => 16L // Default for complex types
        }
      }
    }.sum + 8L // Row overhead
  }
}
```

### 4. Configuration System Implementation

#### Enhanced Configuration Schema
```json
{
  "storage": {
    "mode": "local|hdfs|hybrid",
    "autoDetectSize": true,
    "sizeThresholds": {
      "smallDB": "1GB",
      "mediumDB": "10GB", 
      "largeDB": "50GB"
    },
    "local": {
      "basePath": "./data/migration",
      "tempPath": "./data/temp",
      "backupPath": "./data/backup",
      "format": "auto|parquet|csv|json",
      "compression": "auto|snappy|gzip|lz4",
      "createDirectories": true,
      "cleanupOnSuccess": false,
      "partitioning": {
        "strategy": "adaptive|fixed|hash|range",
        "minPartitions": 1,
        "maxPartitions": 50,
        "targetPartitionSizeMB": 128
      }
    }
  },
  
  "performance": {
    "adaptiveSettings": {
      "enabled": true,
      "memoryOptimization": true,
      "dynamicPartitioning": true,
      "cacheOptimization": true
    },
    "sparkOptimizations": {
      "adaptiveQueryExecution": true,
      "adaptiveCoalescing": true,
      "broadcastJoinThreshold": "100MB",
      "maxRecordsPerFile": 1000000
    },
    "monitoring": {
      "enabled": true,
      "metricsCollection": true,
      "performanceBaselining": true
    }
  },
  
  "development": {
    "enabled": false,
    "embeddedDatabases": {
      "cassandra": {
        "type": "embedded|testcontainer|external",
        "port": 9142,
        "dataPath": "./dev-data/cassandra"
      },
      "oracle": {
        "type": "h2|postgresql|testcontainer",
        "connectionString": "jdbc:h2:./dev-data/oracle;MODE=Oracle"
      }
    },
    "sampleData": {
      "generateSamples": true,
      "sampleSize": "10MB",
      "tablesIncluded": ["deviceeventualinfo", "dualimeiinfo_by_primary_imei"],
      "dataPattern": "realistic|random|minimal"
    }
  }
}
```

#### Configuration Validation
```scala
object ConfigurationValidator {
  
  case class ValidationResult(valid: Boolean, errors: List[String], warnings: List[String])
  
  def validateConfiguration(config: Config): ValidationResult = {
    val errors = mutable.ListBuffer[String]()
    val warnings = mutable.ListBuffer[String]()
    
    // Validate storage configuration
    validateStorageConfig(config, errors, warnings)
    
    // Validate performance settings
    validatePerformanceConfig(config, errors, warnings)
    
    // Validate development settings
    validateDevelopmentConfig(config, errors, warnings)
    
    ValidationResult(
      valid = errors.isEmpty,
      errors = errors.toList,
      warnings = warnings.toList
    )
  }
  
  private def validateStorageConfig(config: Config, errors: mutable.ListBuffer[String], warnings: mutable.ListBuffer[String]): Unit = {
    // Validate storage mode
    val storageMode = config.getString("storage.mode")
    if (!Set("local", "hdfs", "hybrid").contains(storageMode)) {
      errors += s"Invalid storage mode: $storageMode. Must be one of: local, hdfs, hybrid"
    }
    
    // Validate local storage path
    if (storageMode == "local" || storageMode == "hybrid") {
      val basePath = config.getString("storage.local.basePath")
      val path = Paths.get(basePath)
      
      if (!Files.exists(path.getParent)) {
        if (config.getBoolean("storage.local.createDirectories")) {
          warnings += s"Parent directory does not exist: ${path.getParent}. Will be created automatically."
        } else {
          errors += s"Base path parent directory does not exist: ${path.getParent}"
        }
      }
      
      // Check available disk space
      val availableSpace = Files.getFileStore(path.getParent).getUsableSpace
      if (availableSpace < 10L * 1024 * 1024 * 1024) { // 10GB
        warnings += s"Low disk space available: ${availableSpace / (1024 * 1024 * 1024)}GB"
      }
    }
    
    // Validate format settings
    val format = config.getString("storage.local.format")
    if (!Set("auto", "parquet", "csv", "json").contains(format)) {
      errors += s"Invalid format: $format. Must be one of: auto, parquet, csv, json"
    }
  }
}
```

## Configuration Guidelines

### 1. Environment-Specific Configurations

#### Development Configuration
```json
{
  "storage": {
    "mode": "local",
    "local": {
      "basePath": "./dev-data",
      "format": "json",
      "compression": "snappy"
    }
  },
  "development": {
    "enabled": true,
    "embeddedDatabases": {
      "cassandra": {"type": "embedded"},
      "oracle": {"type": "h2"}
    }
  },
  "sparkMaster": "local[2]"
}
```

#### Production Configuration
```json
{
  "storage": {
    "mode": "hybrid",
    "local": {
      "basePath": "/opt/migration/data",
      "format": "parquet", 
      "compression": "snappy"
    }
  },
  "performance": {
    "adaptiveSettings": {
      "enabled": true,
      "memoryOptimization": true
    }
  },
  "sparkMaster": "local[*]"
}
```

### 2. Size-Based Configuration Recommendations

| Data Size | Storage Mode | Format | Partitions | Memory |
|-----------|--------------|---------|------------|---------|
| < 100MB   | Local        | JSON    | 1          | 1GB     |
| 100MB-1GB | Local        | Parquet | 2-4        | 2GB     |
| 1GB-10GB  | Local        | Parquet | 4-20       | 4GB     |
| 10GB-50GB | Hybrid       | Parquet | 20-50      | 8GB     |
| > 50GB    | HDFS         | CSV     | 100-200    | 16GB    |

## Performance Optimization

### 1. Memory Management Guidelines

#### Memory Allocation Strategy
```scala
object MemoryOptimizer {
  
  def calculateOptimalMemorySettings(dataSize: Long): MemoryConfig = {
    val systemMemoryGB = getSystemMemoryGB()
    
    dataSize match {
      case size if size < 100 * 1024 * 1024 => // < 100MB
        MemoryConfig(
          driverMemory = "1g",
          executorMemory = "1g", 
          offHeapEnabled = false
        )
        
      case size if size < 1024 * 1024 * 1024 => // < 1GB
        MemoryConfig(
          driverMemory = "2g",
          executorMemory = "2g",
          offHeapEnabled = false
        )
        
      case size if size < 10L * 1024 * 1024 * 1024 => // < 10GB
        MemoryConfig(
          driverMemory = s"${math.min(4, systemMemoryGB / 4)}g",
          executorMemory = s"${math.min(8, systemMemoryGB / 2)}g",
          offHeapEnabled = true
        )
        
      case _ =>
        MemoryConfig(
          driverMemory = s"${math.min(8, systemMemoryGB / 4)}g",
          executorMemory = s"${math.min(16, systemMemoryGB / 2)}g",
          offHeapEnabled = true
        )
    }
  }
}
```

### 2. Spark Configuration Optimization

#### Size-Based Spark Settings
```scala
object SparkConfigOptimizer {
  
  def generateOptimalSparkConfig(dataSize: Long, storageMode: String): Map[String, String] = {
    val baseConfig = Map(
      "spark.sql.adaptive.enabled" -> "true",
      "spark.sql.adaptive.coalescePartitions.enabled" -> "true",
      "spark.sql.adaptive.skewJoin.enabled" -> "true"
    )
    
    val sizeSpecificConfig = dataSize match {
      case size if size < 100 * 1024 * 1024 => Map( // < 100MB
        "spark.master" -> "local[1]",
        "spark.sql.shuffle.partitions" -> "2",
        "spark.sql.adaptive.coalescePartitions.minPartitionNum" -> "1"
      )
      
      case size if size < 1024 * 1024 * 1024 => Map( // < 1GB
        "spark.master" -> "local[2]",
        "spark.sql.shuffle.partitions" -> "10",
        "spark.sql.adaptive.coalescePartitions.minPartitionNum" -> "2"
      )
      
      case size if size < 10L * 1024 * 1024 * 1024 => Map( // < 10GB
        "spark.master" -> s"local[${math.min(4, Runtime.getRuntime.availableProcessors())}]",
        "spark.sql.shuffle.partitions" -> "50",
        "spark.sql.adaptive.coalescePartitions.minPartitionNum" -> "4"
      )
      
      case _ => Map( // > 10GB
        "spark.master" -> "yarn-cluster",
        "spark.sql.shuffle.partitions" -> "200"
      )
    }
    
    val storageSpecificConfig = storageMode match {
      case "local" => Map(
        "spark.sql.adaptive.localShuffleReader.enabled" -> "true",
        "spark.sql.files.maxPartitionBytes" -> "134217728" // 128MB
      )
      case "hdfs" => Map(
        "spark.hadoop.fs.hdfs.impl.disable.cache" -> "false",
        "spark.sql.files.maxPartitionBytes" -> "268435456" // 256MB
      )
      case _ => Map.empty
    }
    
    baseConfig ++ sizeSpecificConfig ++ storageSpecificConfig
  }
}
```

## Migration Strategy

### 1. Phased Migration Approach

#### Phase 1: Foundation (Weeks 1-3)
**Objectives**: Establish infrastructure and compatibility
**Deliverables**:
- Storage abstraction layer implementation
- Multi-format support system
- Enhanced configuration management
- Development environment setup

**Implementation Steps**:
1. Create `StorageProvider` interface and implementations
2. Implement `LocalStorageProvider` and `HDFSStorageProvider`
3. Add multi-format support (`FormatManager`)
4. Enhance configuration schema and validation
5. Set up development environment with embedded databases

**Success Criteria**:
- All unit tests passing
- Storage abstraction working for sample data
- Development environment operational

#### Phase 2: Integration (Weeks 4-7)
**Objectives**: Integrate new components with existing system
**Deliverables**:
- Enhanced `CommonMethods` with dual-mode support
- Adaptive processing engine
- Error handling and recovery system
- Performance monitoring framework

**Implementation Steps**:
1. Create backward-compatible `CommonMethods` wrapper
2. Implement `DataSizeDetector` and `AdaptiveProcessor`
3. Add comprehensive error handling system
4. Integrate performance monitoring
5. Create migration testing framework

#### Phase 3: Gradual Migration (Weeks 8-13)
**Objectives**: Migrate tables from HDFS to local storage
**Migration Order**:
1. **Week 8-9**: Small tables (< 1GB) - `deviceeventualinfo`
2. **Week 10-11**: Medium tables (1-10GB) - `dualimeiinfo_by_primary_imei`
3. **Week 12-13**: Large tables (> 10GB) - `serializeddevicehistory_v2`

**Per-Table Migration Process**:
1. Data size analysis and strategy determination
2. Backup creation and validation
3. Parallel extraction to new storage format
4. Data integrity validation
5. Performance comparison
6. Traffic switchover
7. Old data cleanup

### 2. Risk Mitigation During Migration

#### Pre-Migration Checklist
- [ ] System resource validation (disk space, memory, CPU)
- [ ] Configuration backup created
- [ ] Data backup completed and verified
- [ ] Performance baseline established
- [ ] Rollback procedures tested
- [ ] Monitoring systems configured

#### Migration Validation Steps
```scala
object MigrationValidator {
  
  def validateMigration(tableName: String, originalPath: String, newPath: String): ValidationResult = {
    val checks = List(
      validateRecordCount(originalPath, newPath),
      validateDataIntegrity(originalPath, newPath),
      validateSchemaCompatibility(originalPath, newPath),
      validatePerformance(tableName, newPath)
    )
    
    ValidationResult(
      tableName = tableName,
      checksPerformed = checks.size,
      checksPassed = checks.count(_.passed),
      issues = checks.filterNot(_.passed).map(_.issue),
      recommendation = generateRecommendation(checks)
    )
  }
  
  private def validateRecordCount(originalPath: String, newPath: String): CheckResult = {
    val originalCount = readRecordCount(originalPath)
    val newCount = readRecordCount(newPath)
    
    CheckResult(
      checkType = "record_count",
      passed = originalCount == newCount,
      issue = if (originalCount != newCount) 
        s"Record count mismatch: original=$originalCount, new=$newCount" 
      else "",
      details = Map("originalCount" -> originalCount, "newCount" -> newCount)
    )
  }
}
```

## Development Guidelines

### 1. Code Structure and Organization

```
src/main/scala/com/tmobile/
├── common/
│   ├── CommonMethods.scala              # Enhanced with storage abstraction
│   ├── storage/
│   │   ├── StorageProvider.scala        # Storage abstraction interface
│   │   ├── LocalStorageProvider.scala   # Local file system implementation
│   │   ├── HDFSStorageProvider.scala    # HDFS implementation
│   │   └── StorageManagerFactory.scala  # Factory for storage providers
│   ├── format/
│   │   ├── DataFormat.scala             # Format definitions
│   │   ├── FormatManager.scala          # Format selection logic
│   │   └── converters/                  # Format-specific converters
│   ├── adaptive/
│   │   ├── DataSizeDetector.scala       # Size estimation logic
│   │   ├── AdaptiveProcessor.scala      # Processing optimization
│   │   └── PerformanceOptimizer.scala   # Performance tuning
│   ├── config/
│   │   ├── ConfigurationManager.scala   # Enhanced configuration handling
│   │   └── ConfigurationValidator.scala # Configuration validation
│   └── error/
│       ├── ErrorHandler.scala           # Error classification and handling
│       ├── CheckpointManager.scala      # Migration checkpointing
│       └── RollbackManager.scala        # Rollback operations
├── dlmExtract/                          # Enhanced extraction components
└── dlmIngestion/                        # Enhanced ingestion components
```

### 2. Coding Standards

#### Interface Design
```scala
// Use traits for abstraction
trait StorageProvider {
  def initialize(config: Config): Unit
  def writeDataFrame(df: DataFrame, path: String, format: String, options: Map[String, String]): Unit
  def readDataFrame(spark: SparkSession, path: String, format: String, schema: StructType): DataFrame
}

// Use case classes for data transfer
case class DataSizeEstimate(
  estimatedRows: Long,
  estimatedSizeBytes: Long,
  estimatedSizeMB: Long,
  sampleConfidence: Double
)

// Use sealed traits for controlled hierarchies
sealed trait DataFormat
object DataFormat {
  case object Parquet extends DataFormat
  case object CSV extends DataFormat
  case object JSON extends DataFormat
}
```

#### Error Handling Patterns
```scala
// Use Try for operations that can fail
def estimateTableSize(df: DataFrame): Try[DataSizeEstimate] = {
  Try {
    val count = df.count()
    val sampleData = df.sample(0.01).collect()
    // ... estimation logic
    DataSizeEstimate(count, estimatedSize, estimatedSizeMB, confidence)
  }.recover {
    case ex: Exception =>
      logger.error("Failed to estimate table size", ex)
      throw new DataSizeEstimationException("Unable to estimate table size", ex)
  }
}

// Use Either for operations with expected failure modes
def validateConfiguration(config: Config): Either[ConfigurationError, ValidConfiguration] = {
  // ... validation logic
}
```

### 3. Testing Guidelines

#### Unit Testing Structure
```scala
class LocalStorageProviderSpec extends AnyFlatSpec with Matchers {
  
  "LocalStorageProvider" should "initialize with valid configuration" in {
    val config = ConfigFactory.parseString("""
      storage.local.basePath = "./test-data"
      storage.local.createDirectories = true
    """)
    
    val provider = new LocalStorageProvider()
    provider.initialize(config)
    
    Files.exists(Paths.get("./test-data")) shouldBe true
  }
  
  it should "write and read DataFrame correctly" in {
    val spark = SparkSession.builder()
      .appName("test")
      .master("local[1]")
      .getOrCreate()
    
    import spark.implicits._
    val testData = Seq(
      ("1", "test1", 100),
      ("2", "test2", 200)
    ).toDF("id", "name", "value")
    
    val provider = new LocalStorageProvider()
    provider.initialize(testConfig)
    
    // Test write
    provider.writeDataFrame(testData, "test-table", "parquet", Map("mode" -> "overwrite"))
    
    // Test read
    val readData = provider.readDataFrame(spark, "test-table", "parquet", testData.schema)
    
    readData.count() shouldBe 2
    readData.collect().map(_.getString(1)) should contain allOf("test1", "test2")
  }
}
```

#### Integration Testing
```scala
class MigrationIntegrationSpec extends AnyFlatSpec with Matchers {
  
  "Complete migration workflow" should "migrate small table successfully" in {
    // Setup embedded databases
    val devEnvironment = DevelopmentModeManager.startDevelopmentEnvironment(testConfig)
    
    // Generate sample data
    val sampleData = generateSampleDeviceEventualInfo(1000)
    
    // Execute migration
    val migrationResult = LocalStorageModeFlow.executeLocalStorageMigration(
      tableConfig = deviceEventualInfoConfig,
      globalConfig = testConfig
    )
    
    migrationResult.success shouldBe true
    migrationResult.recordsProcessed shouldBe 1000
    
    // Validate target data
    val targetData = readFromTargetDatabase("deviceeventualinfo")
    targetData.count() shouldBe 1000
  }
}
```

## Testing Framework

### 1. Test Categories and Coverage

#### Unit Tests (Target: 90% coverage)
- Storage provider implementations
- Format conversion logic
- Configuration validation
- Data size estimation algorithms
- Error handling mechanisms

#### Integration Tests
- End-to-end extraction and ingestion workflows
- Storage format compatibility
- Configuration-driven behavior
- Error recovery scenarios

#### Performance Tests
- Benchmark different storage formats
- Measure processing time across data sizes
- Memory usage optimization validation
- Scalability testing

#### Development Environment Tests
- Embedded database functionality
- Sample data generation
- Development workflow validation

### 2. Performance Benchmarking

#### Benchmark Scenarios
```scala
object PerformanceBenchmarkSuite {
  
  val benchmarkScenarios = List(
    BenchmarkScenario("small_dataset_csv", dataSize = "50MB", format = "csv"),
    BenchmarkScenario("small_dataset_parquet", dataSize = "50MB", format = "parquet"),
    BenchmarkScenario("medium_dataset_parquet", dataSize = "1GB", format = "parquet"),
    BenchmarkScenario("large_dataset_hybrid", dataSize = "20GB", format = "auto")
  )
  
  def runBenchmarks(): BenchmarkReport = {
    val results = benchmarkScenarios.map { scenario =>
      logger.info(s"Running benchmark: ${scenario.name}")
      
      val startTime = System.currentTimeMillis()
      
      // Generate test data
      val testData = generateTestDataset(scenario.dataSize)
      
      // Run migration
      val migrationResult = executeMigration(testData, scenario.format)
      
      val endTime = System.currentTimeMillis()
      
      BenchmarkResult(
        scenario = scenario,
        executionTime = endTime - startTime,
        recordsPerSecond = migrationResult.recordCount / ((endTime - startTime) / 1000.0),
        memoryUsage = getCurrentMemoryUsage(),
        success = migrationResult.success
      )
    }
    
    BenchmarkReport(results, generateRecommendations(results))
  }
}
```

## Operational Procedures

### 1. Deployment Procedures

#### Pre-Deployment Checklist
- [ ] Configuration files updated and validated
- [ ] Required disk space available (2x data size + 20% buffer)
- [ ] Memory requirements met
- [ ] Backup systems operational
- [ ] Monitoring systems configured
- [ ] Rollback procedures documented and tested

#### Deployment Steps
1. **Configuration Backup**
   ```bash
   cp config/extract_config.json config/backup/extract_config_$(date +%Y%m%d_%H%M%S).json
   ```

2. **Update Application**
   ```bash
   # Update JAR file
   cp target/scala-2.12/tetra-elevate-conversion_2.12-2.0.jar /app/tetra/DLM/jar/
   
   # Update configuration
   cp config/enhanced_extract_config.json /app/tetra/DLM/config/extract_config.json
   ```

3. **Validate Configuration**
   ```bash
   # Run configuration validation
   java -cp /app/tetra/DLM/jar/tetra-elevate-conversion_2.12-2.0.jar \
        com.tmobile.config.ConfigurationValidator \
        /app/tetra/DLM/config/extract_config.json
   ```

4. **Test with Small Dataset**
   ```bash
   # Run migration test
   /app/tetra/DLM/scripts/test_migration.sh deviceeventualinfo 100
   ```

### 2. Monitoring and Alerting

#### Key Metrics to Monitor
```yaml
metrics:
  performance:
    - processing_time_per_table
    - records_per_second
    - memory_utilization
    - disk_io_rate
  
  data_quality:
    - record_count_accuracy
    - data_integrity_score
    - schema_compatibility
  
  system_health:
    - available_disk_space
    - error_rate
    - job_success_rate
    - rollback_frequency

alerts:
  critical:
    - disk_space_below_10_percent
    - data_corruption_detected
    - migration_failure_rate_above_5_percent
  
  warning:
    - processing_time_increased_50_percent
    - memory_usage_above_80_percent
    - error_rate_above_1_percent
```

#### Monitoring Dashboard Configuration
```scala
object MonitoringDashboard {
  
  def setupDashboard(): Unit = {
    // Configure Grafana dashboard for migration monitoring
    val dashboardConfig = DashboardConfig(
      datasource = "prometheus",
      refreshInterval = "30s",
      panels = List(
        Panel("Processing Time", "processing_time_seconds", "time_series"),
        Panel("Records/Second", "records_per_second", "stat"),
        Panel("Memory Usage", "memory_usage_percent", "gauge"),
        Panel("Disk Space", "disk_space_percent", "gauge"),
        Panel("Error Rate", "error_rate_percent", "stat")
      )
    )
    
    createGrafanaDashboard(dashboardConfig)
  }
}
```

### 3. Troubleshooting Guide

#### Common Issues and Solutions

**Issue: Insufficient Disk Space**
```bash
# Check available space
df -h /path/to/migration/data

# Clean up temporary files
find /path/to/migration/data/temp -type f -mtime +1 -delete

# Switch to HDFS mode temporarily
# Update configuration: storage.mode = "hdfs"
```

**Issue: Memory OutOfMemory Errors**
```scala
// Adjust Spark configuration
Map(
  "spark.executor.memory" -> "4g", // Increase executor memory
  "spark.sql.shuffle.partitions" -> "20", // Reduce partitions
  "spark.sql.adaptive.coalescePartitions.enabled" -> "true" // Enable coalescing
)
```

**Issue: Performance Degradation**
```scala
// Enable performance debugging
val debugConfig = Map(
  "spark.sql.adaptive.enabled" -> "true",
  "spark.sql.adaptive.logLevel" -> "DEBUG",
  "spark.eventLog.enabled" -> "true",
  "spark.eventLog.dir" -> "/path/to/eventlogs"
)

// Analyze with Spark History Server
// http://localhost:18080
```

## Risk Management

### 1. Risk Assessment Matrix

| Risk | Probability | Impact | Mitigation | Detection |
|------|-------------|---------|------------|-----------|
| Data Corruption | Low | Critical | Checksums, validation, backups | Automated integrity checks |
| Storage Overflow | Medium | High | Monitoring, auto-cleanup, HDFS fallback | Disk space alerts |
| Performance Regression | Low | Medium | Benchmarking, gradual rollout | Performance monitoring |
| Configuration Errors | Medium | High | Validation, testing, rollback | Configuration validation |

### 2. Business Continuity Plan

#### Disaster Recovery Procedures
1. **Data Recovery**
   - Restore from automated backups
   - Verify data integrity
   - Resume processing from last checkpoint

2. **System Recovery**
   - Rollback to previous stable configuration
   - Switch to HDFS mode for immediate continuity
   - Investigate and fix underlying issues

3. **Communication Plan**
   - Notify stakeholders of issues within 15 minutes
   - Provide hourly updates during incidents
   - Conduct post-incident review within 24 hours

## Appendices

### Appendix A: Performance Benchmarks

#### Hardware Configuration
- **CPU**: Intel Xeon E5-2686 v4 (8 cores)
- **Memory**: 32GB RAM
- **Storage**: SSD with 1000 IOPS
- **Network**: 1Gbps

#### Benchmark Results
| Data Size | Format | Storage | Time (min) | Records/sec | Memory (GB) |
|-----------|---------|---------|------------|-------------|-------------|
| 100MB     | JSON    | Local   | 2.3        | 15,000      | 1.2         |
| 100MB     | Parquet | Local   | 1.8        | 19,000      | 1.1         |
| 1GB       | Parquet | Local   | 8.5        | 35,000      | 2.8         |
| 10GB      | Parquet | Local   | 45.2       | 38,000      | 6.2         |
| 10GB      | CSV     | HDFS    | 62.1       | 28,000      | 4.5         |

### Appendix B: Configuration Templates

#### Minimal Configuration (Development)
```json
{
  "storage": {
    "mode": "local",
    "local": {
      "basePath": "./dev-data",
      "format": "json"
    }
  },
  "development": {
    "enabled": true
  }
}
```

#### Production Configuration (Small Database)
```json
{
  "storage": {
    "mode": "local",
    "local": {
      "basePath": "/opt/migration/data",
      "format": "parquet",
      "compression": "snappy"
    }
  },
  "performance": {
    "adaptiveSettings": {
      "enabled": true
    }
  }
}
```

#### Production Configuration (Large Database)
```json
{
  "storage": {
    "mode": "hybrid",
    "local": {
      "basePath": "/opt/migration/data",
      "format": "parquet"
    },
    "hdfs": {
      "basePath": "/app/tetra/DLM/outbound/",
      "format": "csv"
    }
  }
}
```

### Appendix C: Migration Checklist

#### Pre-Migration
- [ ] System requirements validated
- [ ] Configuration prepared and tested
- [ ] Data backup completed
- [ ] Performance baseline established
- [ ] Rollback procedures tested
- [ ] Stakeholder notification sent

#### During Migration
- [ ] Monitor system resources
- [ ] Validate data integrity at each step
- [ ] Track performance metrics
- [ ] Document any issues
- [ ] Maintain communication log

#### Post-Migration
- [ ] Performance comparison completed
- [ ] Data validation passed
- [ ] System monitoring configured
- [ ] Documentation updated
- [ ] Team trained on new procedures
- [ ] Incident response procedures updated

---

**Document Version**: 1.0  
**Last Updated**: January 2024  
**Next Review**: March 2024  
**Owner**: Data Migration Team  
**Reviewers**: Architecture Team, Operations Team