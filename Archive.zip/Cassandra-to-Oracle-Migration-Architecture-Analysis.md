# Cassandra-to-Oracle Migration Architecture Analysis

## Overview
This analysis covers the existing Cassandra-to-Oracle migration system, examining its current architecture, data flow patterns, and identifying opportunities for local storage integration to support small database migrations.

## Current Architecture Components

### 1. Extract Components (`dlmExtract` package)

#### **deviceEventualInfoExtract.scala**
- **Purpose**: Extracts device eventual information from Cassandra
- **Target Table**: `deviceeventualinfo`
- **Output**: CSV files with pipe (|) delimiter to HDFS outbound path
- **Date Filtering**: Supports date range filtering using `eventdate` field
- **Key Features**:
  - Reads from Cassandra using SQL queries via `mycatalog` namespace
  - Writes compressed CSV files (gzip) to HDFS
  - Uses 120 partitions for output optimization

#### **dualimeiinfobyprimaryimeiExtract.scala**
- **Purpose**: Extracts dual IMEI information indexed by primary IMEI
- **Target Table**: `dualimeiinfo_by_primary_imei` 
- **Output**: CSV files with pipe delimiter
- **Date Filtering**: Uses `postingdate` field for filtering
- **Key Features**:
  - Casts all columns to string type for consistency
  - Supports date range filtering from config

#### **serializeddevicehistoryV2Extract.scala**
- **Issue**: File contains shell script content instead of Scala code
- **Actual Implementation**: Likely exists as a separate Scala class
- **Purpose**: Should extract serialized device history v2 data

#### **skuMasterExtract.scala**
- **Status**: Empty file - not implemented
- **Potential Purpose**: SKU master data extraction

### 2. Ingestion Components (`dlmIngestion` package)

#### **Two-Step Ingestion Pattern (CSV-based)**

**deviceEventualInfoIngest.scala**:
- Reads CSV files from outbound path using defined schema
- Removes duplicates based on `serialnumber`
- Writes to Oracle using JDBC append mode

**serializeddevicehistoryV2Ingest.scala**:
- Reads CSV files and applies data cleaning:
  - Handles null values in `transactionid`, `postingtime`, `postingdate`
  - Converts data types (Date, Integer casting)
- Removes duplicates based on multiple keys: `postingdate`, `postingtime`, `serialnumber`, `transactionid`
- Target Oracle table: `serialised_devices_history`

**dualimeiinfobyprimaryimeiIngest.scala**:
- Reads CSV files and removes duplicates by `SERIALNUM`
- Target Oracle table: `dualimeiinfo_primaryimei`

#### **Direct Ingestion Pattern (Cassandra-to-Oracle)**

**dualImeiPrimaryCassToOracle.scala**:
- Bypasses CSV intermediate storage
- Reads directly from Cassandra with date filtering
- Applies data transformations and deduplication
- Direct write to Oracle

**serializedDeviceHistoryCassToOracle.scala**:
- Direct Cassandra to Oracle migration
- Extensive column selection (61+ fields)
- Complex data type transformations
- Target table: `serial_device_hist`

### 3. Common Utilities

#### **CommonMethods.scala** - Core Migration Engine
Key Methods:
- `readCassandraTableQuery()`: Executes SQL queries against Cassandra
- `readFromCSVFile()`: Reads CSV files with schema validation
- `writeToCSVFile()`: Writes DataFrames to compressed CSV files
- `saveToJDBC()`: Batch writes to Oracle with connection management
- `log4jLogGenerate()`: Custom logging setup

#### **SchemaDefinition.scala** - Data Contracts
Defines structured schemas for:
- `dualImeiPrimaryImeiSchema`: 20 fields including dates and strings
- `serializeddevicehistorySchema`: 68+ fields with mixed data types
- `deviceeventualinfoSchema`: 39 fields with timestamps and dates

#### **getTimeCycle.scala** - Time Management
- Handles 15-minute cycle calculations
- Date formatting utilities
- Hour range generation for time-based processing

### 4. Configuration Management

#### **extract_config.json**
```json
{
  "sourceEnabled": "DEV",
  "targetEnabled": "DEV", 
  "warehouse": {
    "outbound_path": "/app/tetra/DLM/outbound/",
    "logdir": "/app/tetra/DLM/logs/"
  },
  "tables": {
    "serializeddevicehistory_v2": {
      "postingdateStart": "2019-01-01",
      "postingdateEnd": "2025-05-13"
    }
  },
  "cassandra_source": {
    "TETRA": { /* connection details */ },
    "HP": { /* connection details */ }
  },
  "oracle_target": {
    "DEV": { /* JDBC connection details */ }
  }
}
```

### 5. Orchestration Scripts

#### **Shell Script Pattern**
- Lock file management prevents concurrent execution
- Spark job submission with optimized configurations
- Error handling and email notifications
- Log rotation (3-day retention)

## Current Data Flow Architecture

```mermaid
graph TB
    subgraph "Source Systems"
        C1[Cassandra TETRA]
        C2[Cassandra HP]
    end
    
    subgraph "Extract Layer"
        E1[deviceEventualInfoExtract]
        E2[dualimeiExtract]
        E3[serializedHistoryExtract]
    end
    
    subgraph "Intermediate Storage"
        HDFS[HDFS Outbound Path<br/>CSV Files with | delimiter<br/>GZIP Compressed]
    end
    
    subgraph "Ingestion Layer"
        I1[deviceEventualInfoIngest]
        I2[dualimeiIngest]
        I3[serializedHistoryIngest]
        D1[Direct CassToOracle Jobs]
    end
    
    subgraph "Target System"
        O[Oracle Database]
    end
    
    C1 --> E1
    C1 --> E2
    C1 --> E3
    C2 --> E1
    C2 --> E2
    
    E1 --> HDFS
    E2 --> HDFS
    E3 --> HDFS
    
    HDFS --> I1
    HDFS --> I2
    HDFS --> I3
    
    I1 --> O
    I2 --> O
    I3 --> O
    
    C1 -.-> D1
    C2 -.-> D1
    D1 -.-> O
    
    style HDFS fill:#e1f5fe
    style O fill:#f3e5f5
```

## Data Transformation and Processing Patterns

### 1. Data Extraction Patterns
- **Query-based extraction**: Uses Spark SQL against Cassandra catalog
- **Date range filtering**: Configurable date ranges for incremental processing
- **Column selection**: Specific column lists or wildcard selection
- **Data type casting**: Uniform string conversion for CSV compatibility

### 2. Data Cleaning and Transformation
- **Null value handling**: Default values for missing data
- **Data type conversions**: String to Date/Integer casting
- **Deduplication strategies**: 
  - Single key: `serialnumber`, `SERIALNUM`
  - Composite keys: `postingdate + postingtime + serialnumber + transactionid`

### 3. Performance Optimizations
- **Partitioning**: 100-200 partitions for large datasets
- **Compression**: GZIP for CSV files, Snappy for Parquet
- **Batch processing**: 10K batch size for Oracle JDBC
- **Connection pooling**: Managed JDBC connections

## Dependencies and Configurations

### External Dependencies
- **Cassandra Connector**: DataStax Spark Cassandra Connector
- **Oracle JDBC**: Oracle thin driver
- **Hadoop/HDFS**: Distributed storage
- **Spark**: Processing engine with YARN cluster mode

### Configuration Dependencies
- Environment-specific connection strings
- Base64 encoded passwords
- SSL certificate management for Cassandra
- Date range configurations per table

## Opportunities for Local Storage Integration

### 1. **Small Database Migration Scenarios**
For databases under 1-10GB, local storage can provide:
- **Simplified Setup**: No HDFS/Hadoop cluster required
- **Reduced Latency**: Local file I/O faster than distributed storage
- **Development Flexibility**: Easier debugging and testing
- **Cost Reduction**: No cluster infrastructure needed

### 2. **Local Storage Integration Points**

#### **CSV File Storage**
```scala
// Current: HDFS path
val outboundPath = extractConfig.getString("warehouse.outbound_path") + "/" + sourceTable

// Proposed: Local path option
val outboundPath = if (isLocalMode) {
  s"./data/outbound/$sourceTable"
} else {
  extractConfig.getString("warehouse.outbound_path") + "/" + sourceTable
}
```

#### **Alternative File Formats**
- **Parquet**: Better compression and type preservation
- **JSON**: Human-readable, schema evolution friendly  
- **Avro**: Schema evolution with backward compatibility

#### **File Organization Strategies**
```
./data/
├── extract/
│   ├── deviceeventualinfo/
│   │   ├── part-000.parquet
│   │   └── part-001.parquet
│   ├── dualimeiinfo/
│   └── serializedhistory/
├── processed/
└── logs/
```

### 3. **Proposed Enhancements**

#### **Configuration-Driven Storage Selection**
```json
{
  "storage": {
    "mode": "local|hdfs",
    "local": {
      "basePath": "./data",
      "format": "parquet|csv|json"
    },
    "hdfs": {
      "basePath": "/app/tetra/DLM/outbound/",
      "format": "csv"
    }
  }
}
```

#### **Adaptive Processing**
- **Small datasets** (<100MB): Single partition, local processing
- **Medium datasets** (100MB-1GB): Multi-partition, local storage
- **Large datasets** (>1GB): Distributed processing with HDFS

#### **Local Development Mode**
- **Docker Compose** setup with local Cassandra/Oracle
- **Embedded databases** for testing
- **Sample data generation** for development

### 4. **Implementation Strategy**

#### **Phase 1: Local Storage Support**
1. Add local file system support to `CommonMethods`
2. Implement format-agnostic read/write methods
3. Add configuration options for storage mode

#### **Phase 2: Enhanced Formats**
1. Parquet support for better performance
2. JSON support for debugging and inspection
3. Schema validation improvements

#### **Phase 3: Optimization**
1. Adaptive partitioning based on data size
2. Compression optimization
3. Memory usage optimization for local processing

## Key Insights and Recommendations

### Current Strengths
- **Modular Design**: Clear separation between extract and ingest
- **Error Handling**: Comprehensive logging and error management
- **Flexibility**: Supports both two-step and direct migration patterns
- **Scalability**: Optimized for large-scale distributed processing

### Areas for Improvement
1. **Code Duplication**: Similar patterns across extract/ingest classes
2. **Configuration Management**: Hard-coded paths and parameters
3. **Testing**: Limited support for local development and testing
4. **Documentation**: Missing API documentation and examples

### Recommendations for Local Storage Integration
1. **Introduce Storage Abstraction Layer**: Abstract storage operations to support multiple backends
2. **Add Development Mode**: Local setup for development and testing
3. **Implement Progressive Enhancement**: Start with small databases, scale up as needed
4. **Enhance Configuration**: Environment-specific and size-adaptive configurations
5. **Add Data Quality Checks**: Validation and profiling capabilities
6. **Improve Error Recovery**: Checkpoint and restart capabilities

This architecture analysis provides a foundation for designing a local storage enhancement that maintains the current system's strengths while adding flexibility for small database scenarios.